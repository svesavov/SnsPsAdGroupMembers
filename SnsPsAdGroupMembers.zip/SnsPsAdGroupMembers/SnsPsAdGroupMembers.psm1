
If ([Environment]::UserInteractive)
{
    [System.Object]$objPsGalMdl = $null;
    Try { [System.Object]$objPsGalMdl = Find-Module -Name "SnsPsAdGroupMembers" -Repository "PSGallery" -ErrorAction "Stop"; } Catch {};
    [System.Array]$arrLocMdl = @();
    [System.Array]$arrLocMdl = Get-Module -Name "SnsPsAdGroupMembers" -ListAvailable;
    If ((-not -not "$($objPsGalMdl.Version)") -and ("$($arrLocMdl[0].Version)" -ne "$($objPsGalMdl.Version)"))
    { Write-Warning "Module ""SnsPsAdGroupMembers"" Have Newer Version. Please Update It."; }
}

##### !!! MODIFY DATABASE PATHS !!!
#####
##### WARNING: Do Not Modify The Order Of The Commands!
#####
##### WARNING: Do Not Move The DataBases On Network Shares Or Mapped Drives! This Will Cause Performance Issues
##### And Eventually DataBase Corruption. Disabling The Network Share Cache Could Delay The DataBase Corruption,
##### But Will Not Prevent It.
#####
#
# Step1. - Make Sure No One Is Using "SnsPsAdGroupMembers" Module At The Moment.
#
# Step2. - Make Sure "SnsPsAdGroupMembers" Is Installed With Scope "AllUsers".
#
# Step3. - Make Sure All The Accounts That Should Use The PSModule Have Modify NTFS Permissions Over The New Folder
# Which Will Host The DataBases.
#
# Step4.
# - If You Need To Move Both The Configuration And Statistics DataBases, Specify The New Folder Path In "CfgDbFolder"
# Property, And Uncomment The Line.
# - If You Need To Move The Configuration DataBase And Leave The Statistics DataBase On Its Current Location, Specify
# The New Folder Path In "CfgDbFolder" Property, Specify The Default Path Into "StatDbFolder" Property, And Uncomment
# Both Lines.
# - If You Need To Move The Statistics DataBase And Leave The Configuration DataBase On Its Current Location, Specify
# The New Folder Path In "StatDbFolder" Property, And Uncomment The Line.
#
# Step5. - Copy The DataBase Files Into The New Locations. In Case The Statistics DataBase Is Not Created Yet Run
# "Invoke-SnsStatisticsDataBaseDefragmentation" CmdLet.
#
# Step6. - Test The Proper Operation Of The PSModule
#
# Step7. - Delete The Default DataBase Files. In Case Both DataBases Are Moved Delete The Default Folder As Well.
#
#
#[SnsAdGroupMembers.SnsInit]::CfgDbFolder = 'C:\ProgramData\SnsAdGroupMembers';
#[SnsAdGroupMembers.SnsInit]::StatDbFolder = 'C:\ProgramData\SnsAdGroupMembers';
#
##### !!! DO NOT COMMENT THE FOLLOWING LINE !!!
[SnsAdGroupMembers.SnsInit]::Initialize();

